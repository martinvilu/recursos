A simple and friendly geometric sans serif font.

![](documentation/figtree-banner.png)

![](documentation/figtree-letterforms.png)

![](documentation/figtree-vibes.png)

![](documentation/figtree-features.png)